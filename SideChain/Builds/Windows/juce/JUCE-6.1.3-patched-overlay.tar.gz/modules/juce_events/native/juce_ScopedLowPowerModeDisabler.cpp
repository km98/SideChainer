/*
  ==============================================================================

   This file is part of the JUCE library.
   Copyright (c) 2020 - Raw Material Software Limited

   JUCE is an open source library subject to commercial or open-source
   licensing.

   The code included in this file is provided under the terms of the ISC license
   http://www.isc.org/downloads/software-support-policy/isc-license. Permission
   To use, copy, modify, and/or distribute this software for any purpose with or
   without fee is hereby granted provided that the above copyright notice and
   this permission notice appear in all copies.

   JUCE IS PROVIDED "AS IS" WITHOUT ANY WARRANTY, AND ALL WARRANTIES, WHETHER
   EXPRESSED OR IMPLIED, INCLUDING MERCHANTABILITY AND FITNESS FOR PURPOSE, ARE
   DISCLAIMED.

  ==============================================================================
*/

namespace juce
{

#if JUCE_MAC

class ScopedLowPowerModeDisabler::Pimpl
{
public:
    Pimpl() = default;
    ~Pimpl() { [[NSProcessInfo processInfo] endActivity: activity]; }

private:
    id activity { [[NSProcessInfo processInfo] beginActivityWithOptions: NSActivityUserInitiatedAllowingIdleSystemSleep
                                                                 reason: @"App must remain in high-power mode"] };

    JUCE_DECLARE_NON_COPYABLE (Pimpl)
    JUCE_DECLARE_NON_MOVEABLE (Pimpl)
};

#else

class ScopedLowPowerModeDisabler::Pimpl {};

#endif

//==============================================================================
ScopedLowPowerModeDisabler::ScopedLowPowerModeDisabler()
    : pimpl (std::make_unique<Pimpl>()) {}

ScopedLowPowerModeDisabler::~ScopedLowPowerModeDisabler() = default;

} // namespace juce
